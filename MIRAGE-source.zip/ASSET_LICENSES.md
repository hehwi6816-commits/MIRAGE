# Asset licenses / تراخيص الأصول

Kenney city and vehicle assets are CC0-1.0 and permit commercial use. Credit is optional; this project credits Kenney. Complete upstream archives are distributed separately to keep this ZIP small. Required runtime meshes and their unmodified License.txt are included here. Bundled selected OBJ/MTL/textures are in MIRAGE/Resources/Kenney with their License.txt. See asset-manifest.json for download provenance and original ZIP hashes.

| Pack | Official source | Used at runtime |
|---|---|---|
| City Kit Commercial2.1 | https://kenney.nl/assets/city-kit-commercial | building-a/b/c + low-detail counterparts; palette |
| Car Kit3.1 | https://kenney.nl/assets/car-kit | sedan; palette |
| City Kit Roads2.2 | https://kenney.nl/assets/city-kit-roads | collected and bundled; road geometry currently original code |

Download mirrors are author Kenney’s OpenGameArt posts, with the same CC0 license supplied in the archives. License legal text: https://creativecommons.org/publicdomain/zero/1.0/

Robot characters, pulse-tool meshes, UI, logo, route layouts, mission text, tone and procedural ambient audio are generated/original project assets licensed under the project MIT license. No commercial game's models, sounds, names, maps, or characters are included. Procedural source is the editable scene and animation source; no closed tools or missing rig files are required.
