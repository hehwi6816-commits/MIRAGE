#!/usr/bin/env python3
"""Regenerate the checked-in Xcode project without third-party dependencies.

Run only after adding/removing source files; opening the existing project needs
neither Python nor this script. Deterministic identifiers keep diffs reviewable.
"""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
objects = {}


def uid(name):
    return hashlib.sha1(name.encode()).hexdigest()[:24].upper()


def add(object_key, isa, **fields):
    key = uid(object_key)
    objects[key] = {"isa": isa, **fields}
    return key


def ref(path, kind):
    return add("file:" + path, "PBXFileReference", lastKnownFileType=kind,
               path=path, sourceTree="<group>")


def build_file(file_id):
    return add("build:" + file_id, "PBXBuildFile", fileRef=file_id)


def group(name, children, path=None):
    fields = {"children": children, "sourceTree": "<group>"}
    fields["path" if path else "name"] = path or name
    return add("group:" + name, "PBXGroup", **fields)


sources = []
app_children = []
for folder in ["App", "Core", "Game", "Views"]:
    children = []
    for path in sorted((ROOT / "MIRAGE" / folder).glob("*.swift")):
        item = ref(folder + "/" + path.name, "sourcecode.swift")
        sources.append(build_file(item))
        children.append(item)
    # File paths include the folder, so logical groups deliberately have no path.
    app_children.append(group(folder, children))

resources = []
resource_refs = []
for path, kind, include in [
    ("Resources/Info.plist", "text.plist.xml", False),
    ("Resources/PrivacyInfo.xcprivacy", "text.xml", True),
    ("Resources/Assets.xcassets", "folder.assetcatalog", True),
    ("Resources/Kenney", "folder", True),
    ("Resources/missions.json", "text.json", True),
    ("Resources/pulse.wav", "audio.wav", True),
    ("Resources/city.wav", "audio.wav", True),
]:
    item = ref(path, kind)
    resource_refs.append(item)
    if include:
        resources.append(build_file(item))
app_children.append(group("Resources", resource_refs))
app_group = group("MIRAGE", app_children, "MIRAGE")

docs_refs = []
for path in sorted((ROOT / "Documentation").glob("*.md")):
    item = ref(path.name, "net.daringfireball.markdown")
    docs_refs.append(item)
    if path.name in ["PRIVACY.ar.md", "PRIVACY.en.md"]:
        resources.append(build_file(item))
docs_group = group("Documentation", docs_refs, "Documentation")

tests = []
test_refs = []
for path in sorted((ROOT / "MIRAGETests").glob("*.swift")):
    item = ref(path.name, "sourcecode.swift")
    tests.append(build_file(item))
    test_refs.append(item)
tests_group = group("MIRAGETests", test_refs, "MIRAGETests")
app_product = add("product:MIRAGE", "PBXFileReference", explicitFileType="wrapper.application",
                  includeInIndex=0, path="MIRAGE.app", sourceTree="BUILT_PRODUCTS_DIR")
test_product = add("product:MIRAGETests", "PBXFileReference", explicitFileType="wrapper.cfbundle",
                   includeInIndex=0, path="MIRAGETests.xctest", sourceTree="BUILT_PRODUCTS_DIR")
products = group("Products", [app_product, test_product])
readme = ref("README.md", "net.daringfireball.markdown")
main_group = group("Main", [app_group, tests_group, docs_group, readme, products])


def phase(name, isa, files):
    return add(name, isa, buildActionMask=2147483647, files=files,
               runOnlyForDeploymentPostprocessing=0)


app_phases = [phase("app:sources", "PBXSourcesBuildPhase", sources),
              phase("app:frameworks", "PBXFrameworksBuildPhase", []),
              phase("app:resources", "PBXResourcesBuildPhase", resources)]
test_phases = [phase("test:sources", "PBXSourcesBuildPhase", tests),
               phase("test:frameworks", "PBXFrameworksBuildPhase", []),
               phase("test:resources", "PBXResourcesBuildPhase", [])]


def configurations(name, common, debug=None, release=None):
    configs = []
    for mode, extra in [("Debug", debug or {}), ("Release", release or {})]:
        configs.append(add(name + ":" + mode, "XCBuildConfiguration",
                           buildSettings={**common, **extra}, name=mode))
    return add(name + ":configs", "XCConfigurationList", buildConfigurations=configs,
               defaultConfigurationIsVisible=0, defaultConfigurationName="Release")


project_configs = configurations("project", {
    "ALWAYS_SEARCH_USER_PATHS": "NO", "CLANG_ENABLE_MODULES": "YES",
    "CLANG_ENABLE_OBJC_ARC": "YES", "CLANG_WARN_DOCUMENTATION_COMMENTS": "YES",
    "CLANG_WARN_QUOTED_INCLUDE_IN_FRAMEWORK_HEADER": "YES", "GCC_C_LANGUAGE_STANDARD": "gnu17",
    "GCC_WARN_64_TO_32_BIT_CONVERSION": "YES", "GCC_WARN_UNDECLARED_SELECTOR": "YES",
    "IPHONEOS_DEPLOYMENT_TARGET": "16.0", "SDKROOT": "iphoneos",
    "SWIFT_VERSION": "5.0", "SWIFT_STRICT_CONCURRENCY": "targeted",
}, {"DEBUG_INFORMATION_FORMAT": "dwarf", "ENABLE_TESTABILITY": "YES",
    "GCC_PREPROCESSOR_DEFINITIONS": ["DEBUG=1", "$(inherited)"],
    "ONLY_ACTIVE_ARCH": "YES", "SWIFT_ACTIVE_COMPILATION_CONDITIONS": "DEBUG $(inherited)",
    "SWIFT_OPTIMIZATION_LEVEL": "-Onone"},
   {"DEBUG_INFORMATION_FORMAT": "dwarf-with-dsym", "SWIFT_COMPILATION_MODE": "wholemodule",
    "SWIFT_OPTIMIZATION_LEVEL": "-O", "VALIDATE_PRODUCT": "YES"})
app_configs = configurations("app", {
    "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon", "CODE_SIGN_STYLE": "Automatic",
    "CURRENT_PROJECT_VERSION": "1", "DEVELOPMENT_TEAM": "",
    "GENERATE_INFOPLIST_FILE": "NO", "INFOPLIST_FILE": "MIRAGE/Resources/Info.plist",
    "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
    "MARKETING_VERSION": "0.1.0", "PRODUCT_BUNDLE_IDENTIFIER": "org.example.mirage",
    "PRODUCT_NAME": "$(TARGET_NAME)", "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator",
    "SUPPORTS_MACCATALYST": "NO", "SUPPORTS_MAC_DESIGNED_FOR_IPHONE_IPAD": "NO",
    "SWIFT_EMIT_LOC_STRINGS": "NO", "TARGETED_DEVICE_FAMILY": "1",
})
test_configs = configurations("test", {
    "BUNDLE_LOADER": "$(TEST_HOST)", "CODE_SIGN_STYLE": "Automatic", "DEVELOPMENT_TEAM": "",
    "GENERATE_INFOPLIST_FILE": "YES", "PRODUCT_BUNDLE_IDENTIFIER": "org.example.mirage.tests",
    "PRODUCT_NAME": "$(TARGET_NAME)", "TEST_HOST": "$(BUILT_PRODUCTS_DIR)/MIRAGE.app/MIRAGE",
    "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator", "TARGETED_DEVICE_FAMILY": "1",
    "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks", "@loader_path/Frameworks"],
})
app_target_id = uid("target:MIRAGE")
project_id = uid("project")
proxy = add("proxy:MIRAGE", "PBXContainerItemProxy", containerPortal=project_id,
            proxyType=1, remoteGlobalIDString=app_target_id, remoteInfo="MIRAGE")
dependency = add("dependency:MIRAGE", "PBXTargetDependency", target=app_target_id, targetProxy=proxy)
app_target = add("target:MIRAGE", "PBXNativeTarget", buildConfigurationList=app_configs,
                 buildPhases=app_phases, buildRules=[], dependencies=[], name="MIRAGE",
                 productName="MIRAGE", productReference=app_product, productType="com.apple.product-type.application")
test_target = add("target:MIRAGETests", "PBXNativeTarget", buildConfigurationList=test_configs,
                  buildPhases=test_phases, buildRules=[], dependencies=[dependency], name="MIRAGETests",
                  productName="MIRAGETests", productReference=test_product, productType="com.apple.product-type.bundle.unit-test")
add("project", "PBXProject", attributes={"BuildIndependentTargetsInParallel": "YES",
    "LastSwiftUpdateCheck": "2600", "LastUpgradeCheck": "2600",
    "TargetAttributes": {app_target: {"CreatedOnToolsVersion": "26.0", "SystemCapabilities": {}},
                         test_target: {"CreatedOnToolsVersion": "26.0", "TestTargetID": app_target}}},
    buildConfigurationList=project_configs, compatibilityVersion="Xcode 14.0", developmentRegion="ar",
    hasScannedForEncodings=0, knownRegions=["ar", "en", "Base"], mainGroup=main_group,
    productRefGroup=products, projectDirPath="", projectRoot="", targets=[app_target, test_target])


def encode(value, indent=0):
    prefix = "\t" * indent
    if isinstance(value, dict):
        return "{\n" + "".join(prefix + "\t" + json.dumps(k) + " = " + encode(v, indent + 1) + ";\n"
                                  for k, v in value.items()) + prefix + "}"
    if isinstance(value, list):
        return "(\n" + "".join(prefix + "\t" + encode(v, indent + 1) + ",\n" for v in value) + prefix + ")"
    return str(value) if isinstance(value, int) else json.dumps(value, ensure_ascii=False)


project = ROOT / "MIRAGE.xcodeproj"
project.mkdir(exist_ok=True)
(project / "project.pbxproj").write_text("// !$*UTF8*$!\n" + encode({"archiveVersion": 1, "classes": {},
    "objectVersion": 56, "objects": objects, "rootObject": project_id}) + "\n")

scheme = ET.Element("Scheme", LastUpgradeVersion="2600", version="1.3")
build = ET.SubElement(scheme, "BuildAction", parallelizeBuildables="YES", buildImplicitDependencies="YES")
entries = ET.SubElement(build, "BuildActionEntries")


def buildable(parent, target, product, name):
    ET.SubElement(parent, "BuildableReference", BuildableIdentifier="primary", BlueprintIdentifier=target,
                  BuildableName=product, BlueprintName=name, ReferencedContainer="container:MIRAGE.xcodeproj")


entry = ET.SubElement(entries, "BuildActionEntry", buildForTesting="YES", buildForRunning="YES",
                      buildForProfiling="YES", buildForArchiving="YES", buildForAnalyzing="YES")
buildable(entry, app_target, "MIRAGE.app", "MIRAGE")
test_action = ET.SubElement(scheme, "TestAction", buildConfiguration="Debug", selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB",
                           selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB", shouldUseLaunchSchemeArgsEnv="YES")
testables = ET.SubElement(test_action, "Testables")
testable = ET.SubElement(testables, "TestableReference", skipped="NO")
buildable(testable, test_target, "MIRAGETests.xctest", "MIRAGETests")
launch = ET.SubElement(scheme, "LaunchAction", buildConfiguration="Debug", selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB",
                      selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB", launchStyle="0", useCustomWorkingDirectory="NO",
                      ignoresPersistentStateOnLaunch="NO", debugDocumentVersioning="YES", debugServiceExtension="internal", allowLocationSimulation="YES")
runnable = ET.SubElement(launch, "BuildableProductRunnable", runnableDebuggingMode="0")
buildable(runnable, app_target, "MIRAGE.app", "MIRAGE")
profile = ET.SubElement(scheme, "ProfileAction", buildConfiguration="Release", shouldUseLaunchSchemeArgsEnv="YES", savedToolIdentifier="",
                       useCustomWorkingDirectory="NO", debugDocumentVersioning="YES")
buildable(ET.SubElement(profile, "BuildableProductRunnable", runnableDebuggingMode="0"), app_target, "MIRAGE.app", "MIRAGE")
ET.SubElement(scheme, "AnalyzeAction", buildConfiguration="Debug")
ET.SubElement(scheme, "ArchiveAction", buildConfiguration="Release", revealArchiveInOrganizer="YES")
ET.indent(scheme)
scheme_dir = project / "xcshareddata/xcschemes"
scheme_dir.mkdir(parents=True, exist_ok=True)
ET.ElementTree(scheme).write(scheme_dir / "MIRAGE.xcscheme", encoding="UTF-8", xml_declaration=True)
print(f"Generated {project.name}: {len(sources)} app sources, {len(tests)} test sources.")
