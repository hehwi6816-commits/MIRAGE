#!/bin/bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { echo 'Requires macOS + Xcode. No archive was made.' >&2; exit 1; }
: "${TEAM_ID:?Set your Apple Developer Team ID}"
: "${BUNDLE_ID:?Set your registered game Bundle ID}"
cd "$(dirname "$0")/.."
xcodebuild -project MIRAGE.xcodeproj -scheme MIRAGE -configuration Release \
 -destination 'generic/platform=iOS' -archivePath build/MIRAGE.xcarchive \
 DEVELOPMENT_TEAM="$TEAM_ID" PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" archive
