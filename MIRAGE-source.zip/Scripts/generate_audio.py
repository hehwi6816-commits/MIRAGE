#!/usr/bin/env python3
"""Original deterministic synthetic game audio, no downloaded samples."""
from pathlib import Path
import math,random,struct,wave
root=Path(__file__).resolve().parents[1]/'MIRAGE/Resources'
random.seed(19)
for name,seconds in [('pulse',0.25),('city',8)]:
    rate=22050; frames=[]; filtered=0
    for index in range(int(rate*seconds)):
        t=index/rate
        if name=='pulse':
            sample=(math.sin(t*2*math.pi*(320-700*t))+random.uniform(-0.25,0.25))*math.exp(-t*24)*0.4
        else:
            filtered=0.985*filtered+0.015*random.uniform(-1,1)
            sample=filtered*0.5+math.sin(t*2*math.pi*70)*0.012*(0.5+0.5*math.sin(t*0.8))
        frames.append(struct.pack('<h',int(max(-1,min(1,sample))*32767)))
    with wave.open(str(root/(name+'.wav')),'wb') as output:
        output.setparams((1,2,rate,0,'NONE','not compressed'));output.writeframes(b''.join(frames))
