import Foundation
import Combine

@MainActor final class SaveStore: ObservableObject {
    @Published var data = ProgressData()
    @Published var error: String?
    private(set) var missions: [Mission] = []
    private let url: URL?
    private var failedReading = false
    init() {
        let folder = try? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        url = folder?.appendingPathComponent("mirage-progress-v1.json")
        if let url, FileManager.default.fileExists(atPath: url.path) {
            do { data = try JSONDecoder().decode(ProgressData.self, from: Data(contentsOf: url)) }
            catch { failedReading = true; self.error = "تعذر قراءة الحفظ السابق. لم يُستبدل الملف. يمكنك إعادة المحاولة من الإعدادات." }
        }
        do {
            guard let file = Bundle.main.url(forResource: "missions", withExtension: "json") else { throw CocoaError(.fileNoSuchFile) }
            let loaded = try JSONDecoder().decode([Mission].self, from: Data(contentsOf: file))
            guard loaded.count == 5, Set(loaded.map(\.id)).count == 5,
                  loaded.enumerated().allSatisfy({ $0.element.id == $0.offset + 1 && $0.element.targetCount > 0 && $0.element.seconds > 0 }) else { throw CocoaError(.coderInvalidValue) }
            missions = loaded
        } catch { missions = []; self.error = "تعذر تحميل ملف المهمات. تحقق من موارد المشروع." }
        data.rollDay(Self.dayKey())
    }
    static func dayKey() -> String {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy-MM-dd"; return f.string(from: Date())
    }
    func save() {
        // Preserve a corrupt existing save until the user explicitly resets it.
        guard error == nil else { return }
        guard let url else { error = "مسار الحفظ غير متاح."; return }
        do { try JSONEncoder().encode(data).write(to: url, options: .atomic) }
        catch { self.error = "تعذر حفظ التقدم على الجهاز." }
    }
    func reset() { data = ProgressData(); failedReading = false; error = nil; save() }
    func retrySave() {
        if failedReading {
            guard let url else { return }
            do { data = try JSONDecoder().decode(ProgressData.self, from: Data(contentsOf: url)); failedReading = false; error = nil }
            catch { self.error = "ملف الحفظ السابق غير قابل للقراءة. لم يُستبدل."; return }
        }
        error = nil; save()
    }
}
