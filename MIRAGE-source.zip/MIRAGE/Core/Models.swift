import Foundation

enum MissionKind: String, Codable { case identify, moving, rescue, precision, timed }
struct Mission: Codable, Identifiable {
    let id: Int
    let title: String
    let briefing: String
    let kind: MissionKind
    let targetCount: Int
    let seconds: Double
    let reward: Int
    let night: Bool
}
struct MissionResult {
    let mission: Int
    let success: Bool
    let hits: Int
    let shots: Int
    let civilians: Int
    let secondsLeft: Double
    var accuracy: Double { shots > 0 ? Double(hits) / Double(shots) : 0 }
    var stars: Int { !success ? 0 : civilians > 0 ? 1 : accuracy >= 0.85 ? 3 : accuracy >= 0.5 ? 2 : 1 }
    var score: Int { max(0, hits * 100 + Int(secondsLeft) * 2 - (shots - hits) * 15 - civilians * 300) }
}
struct ProgressData: Codable {
    var coins = 0
    var experience = 0
    var stars: [Int: Int] = [:]
    var bestScores: [Int: Int] = [:]
    var unlockedSkins = ["sand"]
    var selectedSkin = "sand"
    var sound = true
    var haptics = true
    var sensitivity = 0.8
    var quality = "balanced"
    var completedToday = 0
    var dailyMissions: [Int] = []
    var dailyDate = ""
    var dailyClaimed = false
    var level: Int { 1 + experience / 300 }
    func canPlay(_ id: Int) -> Bool { id == 1 || (stars[id - 1] ?? 0) > 0 }
    mutating func rollDay(_ day: String) {
        if dailyDate != day { dailyDate = day; completedToday = 0; dailyMissions = []; dailyClaimed = false }
    }
    @discardableResult mutating func apply(_ result: MissionResult, reward: Int, day: String) -> Int {
        rollDay(day)
        guard result.success else { return 0 }
        let old = stars[result.mission] ?? 0
        let delta = max(0, result.stars - old)
        var earned = old == 0 ? reward : delta * 25
        stars[result.mission] = max(old, result.stars)
        bestScores[result.mission] = max(bestScores[result.mission] ?? 0, result.score)
        if old == 0 { experience += 100 }
        if !dailyMissions.contains(result.mission) { dailyMissions.append(result.mission); completedToday += 1 }
        if completedToday >= 3 && !dailyClaimed { earned += 100; dailyClaimed = true }
        coins += earned
        return earned
    }
    mutating func buy(_ skin: String, price: Int) -> Bool {
        guard ["sand", "ice", "ember"].contains(skin), !unlockedSkins.contains(skin), price >= 0, coins >= price else { return false }
        coins -= price; unlockedSkins.append(skin); selectedSkin = skin
        return true
    }
}
