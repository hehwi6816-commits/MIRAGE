import SwiftUI
import SceneKit

struct CitySurface: UIViewRepresentable {
    @ObservedObject var game: GameEngine
    func makeCoordinator() -> Coordinator { Coordinator(game:game) }
    func makeUIView(context: Context) -> SCNView {
        let view = SCNView(); view.backgroundColor = .black
        view.autoenablesDefaultLighting = false; view.allowsCameraControl = false
        view.preferredFramesPerSecond = 60; view.isPlaying = true
        let pan = UIPanGestureRecognizer(target:context.coordinator,action:#selector(Coordinator.pan(_:)))
        pan.maximumNumberOfTouches = 1; view.addGestureRecognizer(pan); game.view = view
        return view
    }
    func updateUIView(_ view: SCNView, context: Context) {
        if view.scene !== game.scene { view.scene = game.scene; view.pointOfView = game.scene?.rootNode.childNodes.first(where: { $0.camera != nil }); game.configureQuality() }
    }
    @MainActor final class Coordinator: NSObject {
        let game: GameEngine
        init(game:GameEngine) { self.game = game }
        @objc func pan(_ gesture: UIPanGestureRecognizer) {
            let delta = gesture.translation(in:gesture.view)
            game.aim(dx:delta.x,dy:delta.y); gesture.setTranslation(.zero,in:gesture.view)
        }
    }
}
struct ScopeOverlay: View {
    let scoped: Bool
    var body: some View {
        Canvas { context,size in
            let center = CGPoint(x:size.width/2,y:size.height/2)
            let radius = min(size.width,size.height)*0.42
            if scoped {
                var mask = Path(CGRect(origin:.zero,size:size)); mask.addEllipse(in:CGRect(x:center.x-radius,y:center.y-radius,width:2*radius,height:2*radius))
                context.fill(mask,with:.color(.black.opacity(0.94)),style:FillStyle(eoFill:true))
                context.stroke(Path(ellipseIn:CGRect(x:center.x-radius,y:center.y-radius,width:2*radius,height:2*radius)),with:.color(.white.opacity(0.5)),lineWidth:2)
            }
            var lines = Path()
            let extent: CGFloat = scoped ? radius : 12
            lines.move(to:CGPoint(x:center.x-extent,y:center.y)); lines.addLine(to:CGPoint(x:center.x+extent,y:center.y))
            lines.move(to:CGPoint(x:center.x,y:center.y-extent)); lines.addLine(to:CGPoint(x:center.x,y:center.y+extent))
            context.stroke(lines,with:.color(scoped ? .black.opacity(0.85) : .white),lineWidth:1)
            context.fill(Path(ellipseIn:CGRect(x:center.x-2,y:center.y-2,width:4,height:4)),with:.color(.orange))
        }.allowsHitTesting(false).ignoresSafeArea()
    }
}
struct GameRootView: View {
    @EnvironmentObject private var game: GameEngine
    @EnvironmentObject private var store: SaveStore
    @Environment(\.scenePhase) private var phase
    @State private var page = "home"
    @State private var confirmReset = false
    var body: some View {
        ZStack {
            CitySurface(game:game).ignoresSafeArea()
            if !game.loaded {
                Color.black.opacity(0.8).ignoresSafeArea()
                if let error = game.loadError { VStack(spacing:16) { Text(error); Button("إعادة المحاولة") { game.loadError = nil; Task { await game.load() } } }.padding() }
                else { ProgressView("جارٍ تحميل المدينة…").tint(.white).foregroundStyle(.white) }
            } else if game.playing {
                ScopeOverlay(scoped:game.scoped)
                if let result = game.result { results(result) }
                else if game.paused { pauseMenu }
                else { hud }
            } else { menu }
        }
        .foregroundStyle(.white).tint(.orange)
        .font(.system(.body,design:.rounded))
        .environment(\.layoutDirection,.rightToLeft)
        .task { await game.load() }
        .onChange(of:phase) { value in game.lifecycle(active:value == .active); if value != .active { store.save() } }
        .alert("مسح التقدم؟",isPresented:$confirmReset) {
            Button("مسح",role:.destructive) { store.reset() }
            Button("إلغاء",role:.cancel) {}
        } message: { Text("ستُمسح العملات والنتائج والإعدادات المحلية فقط.") }
    }
    private var menu: some View {
        HStack {
            ScrollView {
            VStack(alignment:.leading,spacing:12) {
                Text("M I R A G E").font(.system(size:34,weight:.black,design:.rounded)).foregroundStyle(.orange)
                Text("سَراب · مرصد المدينة").font(.title3.bold())
                Text("المستوى \(store.data.level)  ·  ◈ \(store.data.coins)").font(.caption).foregroundStyle(.white.opacity(0.7))
                if let error = store.error { Text(error).font(.caption).foregroundStyle(.orange) }
                if page == "home" {
                    action("العب",icon:"play.fill") { if let m = store.missions.first(where: { store.data.canPlay($0.id) && (store.data.stars[$0.id] ?? 0) == 0 }) ?? store.missions.first { game.start(m) } }
                    action("المهمات",icon:"map") { page = "missions" }
                    action("المعدات",icon:"paintbrush.pointed") { page = "gear" }
                    action("الإعدادات",icon:"slider.horizontal.3") { page = "settings" }
                    Text("تحدي اليوم: أكمل 3 مهمات مختلفة · \(store.data.completedToday)/3 · مكافأة 100 ◈").font(.caption)
                } else if page == "missions" {
                    Group {
                        ForEach(store.missions) { m in
                            action("\(m.id). \(m.title)  \(String(repeating:"★",count:store.data.stars[m.id] ?? 0))",icon:store.data.canPlay(m.id) ? "play.circle" : "lock") { game.start(m) }
                                .disabled(!store.data.canPlay(m.id))
                            Text(m.briefing).font(.caption).foregroundStyle(.white.opacity(0.75))
                            Text("أفضل نتيجة: \(store.data.bestScores[m.id] ?? 0)").font(.caption2)
                        }
                    }
                } else if page == "gear" {
                    Text("أشكال فقط؛ كل المهمات قابلة للإكمال بالمعدات الأساسية.").font(.caption)
                    ForEach(["sand","ice","ember"],id:\.self) { skin in
                        let owned = store.data.unlockedSkins.contains(skin)
                        let price = skin == "ice" ? 150 : 250
                        action((skin == "sand" ? "رملي" : skin == "ice" ? "جليدي" : "جمرة") + (owned ? " ✓" : " · \(price) ◈"),icon:"paintpalette") {
                            if owned { store.data.selectedSkin = skin }
                            else { _ = store.data.buy(skin,price:price) }
                            store.save(); game.configureQuality()
                        }.disabled(!owned && store.data.coins < price)
                    }
                } else {
                    Group {
                        Toggle("الصوت",isOn:$store.data.sound)
                        Toggle("اهتزاز خفيف",isOn:$store.data.haptics)
                        Text("حساسية التصويب").font(.caption)
                        Slider(value:$store.data.sensitivity,in:0.25...1.5)
                        Picker("الجودة",selection:$store.data.quality) {
                            Text("بطارية · 30").tag("battery"); Text("متوازن · 60").tag("balanced"); Text("عالٍ · 60").tag("high")
                        }.pickerStyle(.segmented)
                        Text("هذه معدلات تحديث مستهدفة وليست قياسًا لأداء جهازك. عدّل الجودة عند ارتفاع الحرارة.").font(.caption)
                        if store.error != nil { Button("إعادة محاولة الحفظ") { store.retrySave() } }
                        Button("إعادة ضبط التقدم",role:.destructive) { confirmReset = true }.padding(.top)
                    }
                }
                if page != "home" { action("حفظ ورجوع",icon:"arrow.right") { store.save(); game.configureQuality(); page = "home" } }
            }.padding(22)
            }.frame(width:340).background(.black.opacity(0.8),in:RoundedRectangle(cornerRadius:24))
            Spacer()
        }.padding(.horizontal,20).padding(.vertical,10)
    }
    private var hud: some View {
        VStack {
            HStack(alignment:.top) {
                VStack(alignment:.leading,spacing:5) {
                    Text(game.mission?.title ?? "").font(.headline)
                    Text("الأهداف \(game.hits)/\(game.mission?.targetCount ?? 0) · الوقت \(Int(game.remaining))").font(.caption.monospacedDigit())
                    Text(game.feedback).font(.caption2).foregroundStyle(.orange)
                }.padding(12).background(.black.opacity(0.65),in:RoundedRectangle(cornerRadius:14))
                Spacer()
                Button { game.setPaused(true) } label: { Image(systemName:"pause.fill").padding(16).background(.black.opacity(0.7),in:Circle()) }.accessibilityLabel("إيقاف مؤقت")
            }
            Spacer()
            if game.scoped { HStack { Text("×\(game.zoom,specifier:"%.1f")"); Slider(value:$game.zoom,in:2...10) }.frame(maxWidth:260).padding(12).background(.black.opacity(0.7),in:Capsule()) }
            HStack(spacing:18) {
                Button { game.scoped.toggle() } label: { Label(game.scoped ? "غلق المنظار" : "المنظار",systemImage:"scope").padding(16).background(.black.opacity(0.7),in:Capsule()) }
                Button { game.reload() } label: { Text(game.reloading ? "تعبئة…" : "تعبئة \(game.ammo)/5").padding(16).background(.black.opacity(0.7),in:Capsule()) }.disabled(game.reloading)
                Spacer()
                Button { game.fire() } label: { Image(systemName:"dot.scope").font(.system(size:30)).frame(width:78,height:78).background(.orange,in:Circle()).foregroundStyle(.black) }.accessibilityLabel("إطلاق نبضة")
            }
        }.padding(.horizontal,20).padding(.vertical,14)
    }
    private var pauseMenu: some View {
        VStack(spacing:18) {
            Text("المهمة متوقفة").font(.title.bold())
            Text(game.mission?.briefing ?? "").multilineTextAlignment(.center).frame(maxWidth:500)
            action("متابعة",icon:"play.fill") { game.setPaused(false) }
            action("إنهاء المهمة",icon:"house") { game.home(); page = "home" }
        }.padding(28).background(.black.opacity(0.9),in:RoundedRectangle(cornerRadius:25)).frame(maxWidth:560)
    }
    private func results(_ result: MissionResult) -> some View {
        VStack(spacing:12) {
            Text(result.success ? "اكتملت المهمة" : "حاول مجددًا").font(.largeTitle.bold())
            Text(String(repeating:"★",count:result.stars)).font(.largeTitle).foregroundStyle(.orange)
            Text("النتيجة \(result.score) · الدقة \(Int(result.accuracy*100))٪ · المكافأة \(game.lastReward) ◈")
            if result.civilians > 0 { Text("إصابة المدني لا تُحتسب نجاحًا").foregroundStyle(.orange) }
            HStack {
                Button("إعادة المحاولة") { if let m = game.mission { game.start(m) } }.buttonStyle(.borderedProminent)
                if result.success, let id = game.mission?.id, let next = store.missions.first(where: { $0.id == id+1 }) { Button("المهمة التالية") { game.start(next) }.buttonStyle(.bordered) }
                Button("الرئيسية") { game.home(); page = "home" }.buttonStyle(.bordered)
            }
        }.padding(30).background(.black.opacity(0.9),in:RoundedRectangle(cornerRadius:25))
    }
    private func action(_ title:String,icon:String,run:@escaping()->Void) -> some View {
        Button(action:run) { Label(title,systemImage:icon).frame(maxWidth:.infinity,alignment:.leading).padding(10).background(.white.opacity(0.12),in:RoundedRectangle(cornerRadius:12)) }.buttonStyle(.plain)
    }
}
