import SwiftUI
import SceneKit
import AVFoundation

@MainActor private final class FrameRelay: NSObject {
    weak var engine: GameEngine?
    @objc func tick(_ link: CADisplayLink) { engine?.tick(link) }
}
@MainActor final class GameEngine: ObservableObject {
    @Published var loaded = false
    @Published var loadError: String?
    @Published var mission: Mission?
    @Published var playing = false
    @Published var paused = false
    @Published var scoped = false
    @Published var zoom: Double = 4
    @Published var ammo = 5
    @Published var reloading = false
    @Published var remaining: Double = 0
    @Published var hits = 0
    @Published var shots = 0
    @Published var result: MissionResult?
    @Published var lastReward = 0
    @Published var feedback = ""
    let store: SaveStore
    var scene: SCNScene?
    weak var view: SCNView?
    private var world: WorldBundle?
    private var targets: [Walker] = []
    private var targetNodes: [SCNNode] = []
    private var pool: [SCNNode] = []
    private var link: CADisplayLink?
    private let relay = FrameRelay()
    private var lastTime: CFTimeInterval = 0
    private var uiTime: Double = 0
    private var elapsed: Double = 0
    private var yaw: Float = 0
    private var pitch: Float = -0.56
    private var cooldown = 0.0
    private var reloadLeft = 0.0
    private var remainingInternal = 0.0
    private var shotAudio: AVAudioPlayer?
    private var ambience: AVAudioPlayer?
    init(store: SaveStore) { self.store = store }
    deinit { link?.invalidate() }
    func load() async {
        guard !loaded, loadError == nil else { return }
        do {
            let built = try await Task.detached(priority: .userInitiated) { try WorldBuilder.build() }.value
            world = built; scene = built.scene
            for _ in 0..<10 {
                let ring = SCNNode(geometry: SCNTorus(ringRadius: 0.3, pipeRadius: 0.035))
                ring.geometry?.firstMaterial = WorldBuilder.material(.cyan)
                ring.geometry?.firstMaterial?.emission.contents = UIColor.cyan
                ring.categoryBitMask = 4; ring.isHidden = true; built.scene.rootNode.addChildNode(ring); pool.append(ring)
            }
            relay.engine = self
            let display = CADisplayLink(target: relay, selector: #selector(FrameRelay.tick(_:)))
            display.preferredFramesPerSecond = 60; display.add(to: .main, forMode: .common); link = display
            loaded = true
            prepareAudio(); configureQuality()
        } catch { loadError = "تعذر تحميل نماذج المدينة. تأكد من وجود مجلد Kenney داخل موارد التطبيق." }
    }
    func start(_ mission: Mission) {
        guard loaded, store.data.canPlay(mission.id) else { return }
        targetNodes.forEach { $0.removeFromParentNode() }; targetNodes = []; targets = []
        self.mission = mission; result = nil; ammo = 5; hits = 0; shots = 0
        reloading = false; reloadLeft = 0; cooldown = 0; elapsed = 0
        scoped = false; paused = false; scene?.isPaused = false; playing = true; remainingInternal = mission.seconds; remaining = mission.seconds
        world?.rifle.removeAllActions(); world?.rifle.position = SCNVector3(0.33,-0.36,-0.7); world?.rifle.eulerAngles = SCNVector3Zero
        for fx in pool { fx.removeAllActions(); fx.isHidden = true }
        yaw = 0; pitch = -0.56
        if let world {
            world.scene.background.contents = mission.night ? UIColor(red:0.025,green:0.05,blue:0.12,alpha:1) : UIColor(red:0.4,green:0.61,blue:0.78,alpha:1)
            world.sun.light?.intensity = mission.night ? 230 : 1200
            world.scene.fogColor = mission.night ? UIColor(red:0.04,green:0.07,blue:0.15,alpha:1) : UIColor(red:0.52,green:0.66,blue:0.76,alpha:1)
        }
        for i in 0..<mission.targetCount {
            let training = mission.kind == .precision || mission.kind == .timed
            let node: SCNNode
            if training {
                let g = SCNCylinder(radius:0.6,height:0.12); g.materials = [WorldBuilder.material(.systemRed,metal:0.4)]
                let disk = SCNNode(geometry:g); disk.eulerAngles.x = .pi/2; disk.position.y = 1.7
                node = SCNNode(); node.addChildNode(disk); disk.categoryBitMask = 2
                let center = SCNNode(geometry:SCNSphere(radius:0.15)); center.position = SCNVector3(0,1.7,0.13); center.geometry?.firstMaterial?.emission.contents = UIColor.yellow; center.categoryBitMask = 2; node.addChildNode(center)
            } else { node = WorldBuilder.robot(color:.darkGray,hostile:true) }
            node.name = "target"
            let x: Float = training ? Float(-12 + i * 4) : mission.kind == .rescue ? Float(7 + i * 3) : -8
            let z: Float = training ? Float(-4 + (i % 2) * 9) : 3
            node.position = SCNVector3(x,0,z); scene?.rootNode.addChildNode(node); targetNodes.append(node)
            if mission.kind == .moving || training && i.isMultiple(of:2) {
                targets.append(Walker(node:node,path:[SCNVector3(x,0,z),SCNVector3(x,0,z-10)],speed:training ? 0.7 : 1.1))
            }
        }
        if mission.kind == .rescue {
            let hostage = WorldBuilder.robot(color:.systemBlue); hostage.position = SCNVector3(8.5,0,3)
            scene?.rootNode.addChildNode(hostage); targetNodes.append(hostage)
        }
        feedback = "الشريط الأحمر يحدد الهدف — لا تصب المدنيين"
        resumeAudio()
    }
    func aim(dx: CGFloat, dy: CGFloat) {
        guard playing, !paused, result == nil else { return }
        let factor = Float(store.data.sensitivity) * (scoped ? 0.0015 / Float(zoom / 2) : 0.0025)
        yaw -= Float(dx) * factor; pitch = min(-0.05,max(-1.1,pitch-Float(dy)*factor))
        yaw = min(0.9,max(-0.9,yaw))
    }
    func fire() {
        guard playing, !paused, result == nil, cooldown <= 0, !reloading else { return }
        guard ammo > 0 else { reload(); return }
        ammo -= 1; shots += 1; cooldown = 0.6
        if store.data.sound { shotAudio?.currentTime = 0; shotAudio?.play() }
        if store.data.haptics { UIImpactFeedbackGenerator(style:.light).impactOccurred() }
        world?.rifle.runAction(.sequence([.moveBy(x:0,y:0.04,z:0.12,duration:0.05),.moveBy(x:0,y:-0.04,z:-0.12,duration:0.22)]))
        guard let view else { return }
        let found = view.hitTest(CGPoint(x:view.bounds.midX,y:view.bounds.midY),options:[.categoryBitMask:3,.ignoreHiddenNodes:true,.sortResults:true,.searchMode:SCNHitTestSearchMode.all.rawValue])
        guard let hit = found.first else { feedback = "لم تصب هدفًا"; return }
        var node: SCNNode? = hit.node
        while let current = node, current.name != "target" && current.name != "civilian" { node = current.parent }
        guard let actor = node else { feedback = "خط الرؤية محجوب"; return }
        if actor.name == "civilian" { feedback = "أصبت شخصية محمية"; finish(success:false,civilians:1); return }
        actor.isHidden = true; hits += 1; feedback = "إصابة مؤكدة — تعطيل غير دموي"
        if let fx = pool.first(where: { $0.isHidden }) {
            fx.position = hit.worldCoordinates; fx.isHidden = false; fx.scale = SCNVector3(0.2,0.2,0.2)
            fx.runAction(.sequence([.scale(to:2,duration:0.25),.run { n in n.isHidden = true }]))
        }
        if let mission, hits >= mission.targetCount { finish(success:true,civilians:0) }
    }
    func reload() {
        guard playing, !paused, !reloading, ammo < 5, result == nil else { return }
        reloading = true; reloadLeft = 2.0
        world?.rifle.runAction(.sequence([.rotateBy(x:0.5,y:0,z:0.3,duration:0.35),.wait(duration:1.3),.rotateBy(x:-0.5,y:0,z:-0.3,duration:0.35)]))
    }
    func finish(success: Bool, civilians: Int) {
        guard result == nil, let mission else { return }
        let outcome = MissionResult(mission:mission.id,success:success,hits:hits,shots:shots,civilians:civilians,secondsLeft:remainingInternal)
        result = outcome; paused = true; ambience?.pause()
        lastReward = store.data.apply(outcome,reward:mission.reward,day:SaveStore.dayKey()); store.save()
    }
    func home() { scene?.isPaused = false; playing = false; paused = false; scoped = false; result = nil; ambience?.pause() }
    func setPaused(_ value: Bool) { paused = value; scene?.isPaused = value; if value { ambience?.pause() } else { resumeAudio() } }
    func lifecycle(active: Bool) {
        link?.isPaused = !active; view?.isPlaying = active; lastTime = 0
        if !active { if playing { setPaused(true) }; ambience?.stop(); shotAudio?.stop() }
    }
    func configureQuality() {
        let low = store.data.quality == "battery"
        view?.preferredFramesPerSecond = low ? 30 : 60
        view?.antialiasingMode = store.data.quality == "high" ? .multisampling4X : .none
        link?.preferredFramesPerSecond = low ? 30 : 60
        world?.sun.light?.castsShadow = !low
        world?.sun.light?.shadowMapSize = CGSize(width:store.data.quality == "high" ? 2048 : 1024,height:store.data.quality == "high" ? 2048 : 1024)
        scene?.rootNode.childNode(withName:"dust",recursively:false)?.particleSystems?.first?.birthRate = low ? 0 : (store.data.quality == "high" ? 12 : 6)
        let color: UIColor = store.data.selectedSkin == "ice" ? .cyan : store.data.selectedSkin == "ember" ? .orange : .brown
        world?.rifle.childNodes.first?.geometry?.firstMaterial?.diffuse.contents = color
        resumeAudio()
    }
    func tick(_ display: CADisplayLink) {
        let realDelta = lastTime == 0 ? 0 : max(0,display.timestamp-lastTime)
        let dt = min(0.06,realDelta); lastTime = display.timestamp
        guard loaded, !paused, let world else { return }
        elapsed += dt
        for actor in world.actors {
            let proposal = actor.proposedPosition(Float(dt))
            let blocked = world.actors.contains { other in
                let dx = other.node.position.x-proposal.x, dz = other.node.position.z-proposal.z
                return other !== actor && (dx*dx+dz*dz).squareRoot() < 0.7
            }
            if !blocked { actor.step(Float(dt),walking:true) }
        }
        for actor in targets where !actor.node.isHidden { actor.step(Float(dt),walking:true) }
        // Vehicles use separated, one-way lanes; the stop line is clear of NPC sidewalks.
        let red = Int(elapsed / 7).isMultiple(of:2)
        for signal in world.scene.rootNode.childNodes where signal.name == "signal" {
            signal.geometry?.firstMaterial?.emission.contents = red ? UIColor.red : UIColor.green
        }
        for car in world.cars {
            let direction: Float = car.node.position.x < 0 ? -1 : 1
            let z = car.node.position.z
            let following = world.cars.contains { other in
                let gap = (other.node.position.z-z)*direction
                return other !== car && other.node.position.x == car.node.position.x && gap > 0 && gap < 5
            }
            if !following && !(red && (direction < 0 ? z < -32 && z > -36 : z > -52 && z < -48)) { car.node.position.z += direction * Float(dt) * 4.5 }
            car.node.eulerAngles.y = direction < 0 ? .pi : 0
            if car.node.position.z < -145 { car.node.position.z = 50 }
            if car.node.position.z > 50 { car.node.position.z = -145 }
        }
        let fov: CGFloat = scoped ? 58 / CGFloat(zoom) : 58
        if let lens = world.camera.camera { lens.fieldOfView += (fov-lens.fieldOfView) * min(1,CGFloat(dt)*10) }
        world.camera.eulerAngles = SCNVector3(pitch + Float(sin(elapsed*1.5))*0.0008,yaw,0)
        world.rifle.isHidden = scoped
        if playing && result == nil {
            remainingInternal = max(0,remainingInternal-realDelta); cooldown = max(0,cooldown-realDelta)
            if reloading { reloadLeft -= realDelta; if reloadLeft <= 0 { ammo = 5; reloading = false } }
            uiTime += dt; if uiTime >= 0.1 { remaining = remainingInternal; uiTime = 0 }
            if remainingInternal <= 0 { finish(success:false,civilians:0) }
        }
    }
    private func prepareAudio() {
        if let u = Bundle.main.url(forResource:"pulse",withExtension:"wav") { shotAudio = try? AVAudioPlayer(contentsOf:u); shotAudio?.volume = 0.35; shotAudio?.prepareToPlay() }
        if let u = Bundle.main.url(forResource:"city",withExtension:"wav") { ambience = try? AVAudioPlayer(contentsOf:u); ambience?.numberOfLoops = -1; ambience?.volume = 0.12 }
    }
    private func resumeAudio() { if store.data.sound && playing && !paused { ambience?.play() } else { ambience?.pause() } }
}
