import SceneKit
import ModelIO
import UIKit

/// Built on a worker, then transferred once to the main-actor game owner.
struct WorldBundle: @unchecked Sendable {
    let scene: SCNScene
    let camera: SCNNode
    let rifle: SCNNode
    let sun: SCNNode
    let actors: [Walker]
    let cars: [Walker]
}
final class Walker {
    let node: SCNNode
    let path: [SCNVector3]
    let speed: Float
    var destination = 1
    var phase: Float = 0
    init(node: SCNNode, path: [SCNVector3], speed: Float) {
        self.node = node; self.path = path; self.speed = speed
        node.position = path[0]
    }
    func proposedPosition(_ dt: Float) -> SCNVector3 {
        let goal = path[destination], p = node.position
        let dx = goal.x-p.x, dz = goal.z-p.z, d = sqrt(dx*dx+dz*dz)
        if d < max(0.05,dt*speed) { return goal }
        return SCNVector3(p.x+dx/d*dt*speed,p.y,p.z+dz/d*dt*speed)
    }
    func step(_ dt: Float, walking: Bool) {
        guard path.count > 1 else { return }
        let goal = path[destination], p = node.position
        let dx = goal.x - p.x, dz = goal.z - p.z
        let distance = sqrt(dx * dx + dz * dz)
        if distance < max(0.05, dt * speed) { node.position = goal; destination = (destination + 1) % path.count }
        else {
            node.position.x += dx / distance * speed * dt
            node.position.z += dz / distance * speed * dt
            node.eulerAngles.y = atan2(dx, dz)
        }
        if walking {
            phase += dt * 7
            node.childNode(withName: "leftLeg", recursively: true)?.eulerAngles.x = sin(phase) * 0.35
            node.childNode(withName: "rightLeg", recursively: true)?.eulerAngles.x = -sin(phase) * 0.35
            node.childNode(withName: "leftArm", recursively: true)?.eulerAngles.x = -sin(phase) * 0.22
            node.childNode(withName: "rightArm", recursively: true)?.eulerAngles.x = sin(phase) * 0.22
        }
    }
}

/// The road graph and sidewalk graph occupy separate corridors. Buildings are
/// outside both; paths deliberately do not route actors through road traffic.
enum WorldBuilder {
    static func material(_ color: UIColor, metal: CGFloat = 0, roughness: CGFloat = 0.65) -> SCNMaterial {
        let m = SCNMaterial(); m.diffuse.contents = color; m.lightingModel = .physicallyBased
        m.metalness.contents = metal; m.roughness.contents = roughness; return m
    }
    static func box(_ size: SCNVector3, _ color: UIColor, at p: SCNVector3) -> SCNNode {
        let g = SCNBox(width: CGFloat(size.x), height: CGFloat(size.y), length: CGFloat(size.z), chamferRadius: 0.04)
        g.materials = [material(color)]; let n = SCNNode(geometry: g); n.position = p; n.name = "solid"; return n
    }
    static func robot(color: UIColor, hostile: Bool = false) -> SCNNode {
        let root = SCNNode(); root.name = hostile ? "target" : "civilian"
        let suit = material(color), dark = material(.darkGray), visor = material(.cyan, metal: 0.6, roughness: 0.15)
        func part(_ geometry: SCNGeometry, _ p: SCNVector3, _ name: String, _ m: SCNMaterial) {
            geometry.materials = [m]; let n = SCNNode(geometry: geometry); n.position = p; n.name = name; root.addChildNode(n)
        }
        part(SCNCapsule(capRadius: 0.25, height: 0.8), SCNVector3(0, 1.1, 0), "torso", suit)
        part(SCNSphere(radius: 0.23), SCNVector3(0, 1.72, 0), "head", dark)
        part(SCNBox(width: 0.32, height: 0.10, length: 0.12, chamferRadius: 0.03), SCNVector3(0, 1.74, 0.2), "visor", visor)
        for side: Float in [-1, 1] {
            part(SCNCapsule(capRadius: 0.10, height: 0.62), SCNVector3(side * 0.14, 0.37, 0), side < 0 ? "leftLeg" : "rightLeg", dark)
            part(SCNCapsule(capRadius: 0.09, height: 0.65), SCNVector3(side * 0.35, 1.05, 0), side < 0 ? "leftArm" : "rightArm", suit)
        }
        if hostile { part(SCNTorus(ringRadius: 0.27, pipeRadius: 0.065), SCNVector3(0, 1.38, 0), "redBand", material(.red)) }
        // One inexpensive hit proxy rather than checking tiny mesh triangles.
        let hit = SCNNode(geometry: SCNCapsule(capRadius: 0.44, height: 1.95))
        hit.position.y = 1; hit.name = "hitProxy"; hit.opacity = 0.001
        hit.geometry?.materials = [material(.clear)]; hit.categoryBitMask = 2
        root.addChildNode(hit)
        root.enumerateChildNodes { node, _ in if node.name != "hitProxy" { node.categoryBitMask = 4 } }
        return root
    }
    static func imported(_ name: String, folder: String) throws -> SCNNode {
        guard let url = Bundle.main.url(forResource: name, withExtension: "obj", subdirectory: "Kenney/" + folder) else { throw CocoaError(.fileNoSuchFile) }
        let asset = MDLAsset(url: url)
        asset.loadTextures()
        guard asset.count > 0 else { throw CocoaError(.fileReadCorruptFile) }
        let parent = SCNNode()
        for i in 0..<asset.count { parent.addChildNode(SCNNode(mdlObject: asset.object(at: i))) }
        return parent
    }
    static func build() throws -> WorldBundle {
        let scene = SCNScene()
        scene.background.contents = UIColor(red: 0.40, green: 0.61, blue: 0.78, alpha: 1)
        scene.lightingEnvironment.contents = UIColor(white: 0.75, alpha: 1)
        scene.lightingEnvironment.intensity = 0.8
        scene.fogStartDistance = 110; scene.fogEndDistance = 250; scene.fogColor = UIColor(red: 0.52, green: 0.66, blue: 0.76, alpha: 1)
        let ground = box(SCNVector3(220, 0.2, 240), UIColor(white: 0.27, alpha: 1), at: SCNVector3(0, -0.2, -45)); scene.rootNode.addChildNode(ground)
        // Main road, intersection and pedestrian corridors are real geometry.
        scene.rootNode.addChildNode(box(SCNVector3(11, 0.05, 220), UIColor(white: 0.10, alpha: 1), at: SCNVector3(0, 0, -45)))
        scene.rootNode.addChildNode(box(SCNVector3(210, 0.05, 10), UIColor(white: 0.10, alpha: 1), at: SCNVector3(0, 0, -42)))
        for x: Float in [-10, 10] { scene.rootNode.addChildNode(box(SCNVector3(7, 0.18, 160), UIColor(white: 0.58, alpha: 1), at: SCNVector3(x, 0, -30))) }
        for z in stride(from: -140, through: 45, by: 7) {
            scene.rootNode.addChildNode(box(SCNVector3(0.12, 0.02, 3), .white, at: SCNVector3(0, 0.04, Float(z))))
        }
        // Imported CC0 buildings; repeated clones share geometry and materials.
        let buildings = try ["a", "b", "c"].map { suffix -> SCNNode in
            let high = try imported("building-" + suffix, folder: "Commercial").flattenedClone()
            let low = try imported("low-detail-building-" + suffix, folder: "Commercial").flattenedClone()
            if let geometry = low.geometry { high.geometry?.levelsOfDetail = [SCNLevelOfDetail(geometry: geometry, worldSpaceDistance: 80)] }
            high.geometry?.materials.forEach { $0.lightingModel = .physicallyBased; $0.roughness.contents = 0.6 }
            return high
        }
        for row in 0..<7 {
            for side in [-1, 1] {
                for column in 0..<3 {
                    let b = buildings[(row + column) % buildings.count].clone()
                    let height: Float = Float(10 + ((row * 7 + column * 3) % 7) * 4)
                    let (minV,maxV) = b.boundingBox
                    let h = max(0.01, maxV.y - minV.y)
                    let scale = height / h; b.scale = SCNVector3(scale, scale, scale)
                    let width = (maxV.x - minV.x) * scale
                    // Keep the complete mesh outside the walk corridor.
                    b.position = SCNVector3(Float(side) * (22 + Float(column) * 25 + width / 2), -minV.y * scale, Float(20 - row * 23))
                    b.name = "solid"
                    b.enumerateChildNodes { n, _ in n.categoryBitMask = 1; n.castsShadow = true }
                    scene.rootNode.addChildNode(b)
                }
            }
        }
        for x: Float in [-14, 14] {
            for z in stride(from: -100, through: 25, by: 14) {
                let trunk = box(SCNVector3(0.25, 2, 0.25), .brown, at: SCNVector3(x, 1, Float(z))); scene.rootNode.addChildNode(trunk)
                let foliage = SCNNode(geometry: SCNCone(topRadius: 0.1, bottomRadius: 1.1, height: 2.7)); foliage.position = SCNVector3(x, 3, Float(z)); foliage.geometry?.materials = [material(.systemGreen)]; scene.rootNode.addChildNode(foliage)
                let lamp = box(SCNVector3(0.13, 4, 0.13), .darkGray, at: SCNVector3(x > 0 ? 6 : -6, 2, Float(z))); scene.rootNode.addChildNode(lamp)
                let glow = box(SCNVector3(0.8, 0.12, 0.3), .yellow, at: SCNVector3(lamp.position.x, 4, Float(z))); glow.geometry?.firstMaterial?.emission.contents = UIColor.yellow; scene.rootNode.addChildNode(glow)
            }
        }
        for x: Float in [-6, 6] {
            let signal = box(SCNVector3(0.5,1.0,0.3), .black, at: SCNVector3(x,3,-36)); scene.rootNode.addChildNode(signal)
            let light = SCNNode(geometry: SCNSphere(radius:0.17)); light.position = SCNVector3(x,3,-35.8); light.name = "signal"
            light.geometry?.materials = [material(.red)]; scene.rootNode.addChildNode(light)
        }
        let sun = SCNNode(); sun.light = SCNLight(); sun.light?.type = .directional
        sun.light?.intensity = 1200; sun.light?.castsShadow = true; sun.light?.shadowMode = .deferred
        sun.light?.shadowRadius = 3; sun.light?.shadowMapSize = CGSize(width: 1024,height: 1024)
        sun.eulerAngles = SCNVector3(-1.0, -0.5, 0); scene.rootNode.addChildNode(sun)
        let ambient = SCNNode(); ambient.light = SCNLight(); ambient.light?.type = .ambient; ambient.light?.intensity = 350; scene.rootNode.addChildNode(ambient)
        let dust = SCNParticleSystem()
        dust.birthRate = 6; dust.particleLifeSpan = 6; dust.particleSize = 0.025
        dust.particleColor = UIColor(white:0.9,alpha:0.3); dust.particleVelocity = 0.3
        dust.emitterShape = SCNBox(width:30,height:8,length:30,chamferRadius:0)
        dust.acceleration = SCNVector3(0.05,0,0.02)
        let air = SCNNode(); air.name = "dust"; air.position = SCNVector3(0,4,4); air.addParticleSystem(dust); scene.rootNode.addChildNode(air)
        let roof = box(SCNVector3(14, 20, 8), .darkGray, at: SCNVector3(0, 10, 39)); scene.rootNode.addChildNode(roof)
        let camera = SCNNode(); camera.camera = SCNCamera(); camera.camera?.fieldOfView = 58
        camera.camera?.zFar = 260; camera.camera?.wantsHDR = true; camera.camera?.exposureOffset = 0
        camera.position = SCNVector3(0, 22, 35.3); camera.eulerAngles.x = -0.56; scene.rootNode.addChildNode(camera)
        let rifle = SCNNode()
        rifle.addChildNode(box(SCNVector3(0.16,0.20,0.95), .darkGray, at: SCNVector3(0,0,-0.2)))
        rifle.addChildNode(box(SCNVector3(0.08,0.08,1.1), .black, at: SCNVector3(0,0.02,-1.0)))
        rifle.addChildNode(box(SCNVector3(0.24,0.15,0.35), .brown, at: SCNVector3(0,-0.05,0.35)))
        let optic = SCNNode(geometry: SCNCylinder(radius: 0.075,height: 0.38)); optic.eulerAngles.x = .pi / 2; optic.position = SCNVector3(0,0.19,-0.12); rifle.addChildNode(optic)
        rifle.position = SCNVector3(0.33,-0.36,-0.7); camera.addChildNode(rifle)
        rifle.enumerateChildNodes { n,_ in n.categoryBitMask = 4; n.castsShadow = false }
        var actors: [Walker] = []
        for i in 0..<14 {
            let side: Float = i.isMultiple(of: 2) ? -1 : 1
            let z = Float(-18 + (i * 5) % 40)
            let node = robot(color: [.systemBlue,.systemTeal,.systemPurple,.systemOrange][i % 4]); scene.rootNode.addChildNode(node)
            let path = [SCNVector3(side * 8,0,z), SCNVector3(side * 8,0,z-8), SCNVector3(side * 11,0,z-8), SCNVector3(side * 11,0,z)]
            actors.append(Walker(node: node,path:path,speed:Float(0.55 + Double(i % 4) * 0.13)))
        }
        let carTemplate = try imported("sedan",folder:"Cars")
        var cars: [Walker] = []
        for i in 0..<8 {
            let car = carTemplate.clone(); let (a,b) = car.boundingBox; let s: Float = 3.5 / max(0.01,b.z-a.z); car.scale = SCNVector3(s,s,s)
            let x: Float = i.isMultiple(of:2) ? -2.4 : 2.4
            let start = Float(-120+i*19)
            car.name = "solid"; scene.rootNode.addChildNode(car)
            cars.append(Walker(node:car,path:[SCNVector3(x,-a.y*s,start),SCNVector3(x,-a.y*s,i.isMultiple(of:2) ? 50 : -145)],speed:4.5))
        }
        return WorldBundle(scene:scene,camera:camera,rifle:rifle,sun:sun,actors:actors,cars:cars)
    }
}
