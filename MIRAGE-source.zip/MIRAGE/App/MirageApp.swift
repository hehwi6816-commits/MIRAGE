import SwiftUI

@main struct MirageApp: App {
    @StateObject private var store: SaveStore
    @StateObject private var game: GameEngine
    init() {
        let s = SaveStore(); _store = StateObject(wrappedValue:s); _game = StateObject(wrappedValue:GameEngine(store:s))
    }
    var body: some Scene {
        WindowGroup { GameRootView().environmentObject(store).environmentObject(game).preferredColorScheme(.dark) }
    }
}
