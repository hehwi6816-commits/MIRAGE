import SceneKit
import XCTest
@testable import MIRAGE
final class NavigationTests: XCTestCase {
    func testSidewalkWalkerCannotLeaveReservedCorridor() {
        let node = SCNNode()
        let walker = Walker(node:node,path:[SCNVector3(8,0,10),SCNVector3(8,0,-20),SCNVector3(11,0,-20),SCNVector3(11,0,10)],speed:0.8)
        for _ in 0..<20_000 {
            walker.step(1/60,walking:false)
            XCTAssertGreaterThanOrEqual(node.position.x,8)
            XCTAssertLessThanOrEqual(node.position.x,11)
            XCTAssertGreaterThanOrEqual(node.position.z,-20)
            XCTAssertLessThanOrEqual(node.position.z,10)
        }
    }
}
