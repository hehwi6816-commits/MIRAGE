import XCTest
@testable import MIRAGE

final class ProgressTests: XCTestCase {
    private func win(_ id: Int, hits: Int = 1, shots: Int = 1) -> MissionResult {
        MissionResult(mission:id,success:true,hits:hits,shots:shots,civilians:0,secondsLeft:10)
    }
    func testUnlocksOnlyAfterPreviousSuccess() {
        var p = ProgressData()
        XCTAssertTrue(p.canPlay(1)); XCTAssertFalse(p.canPlay(2))
        _ = p.apply(win(1),reward:120,day:"2026-11-17")
        XCTAssertTrue(p.canPlay(2)); XCTAssertFalse(p.canPlay(3))
    }
    func testReplayCannotFarmFirstClearReward() {
        var p = ProgressData()
        XCTAssertEqual(p.apply(win(1),reward:120,day:"2026-11-17"),120)
        XCTAssertEqual(p.apply(win(1),reward:120,day:"2026-11-17"),0)
        XCTAssertEqual(p.coins,120); XCTAssertEqual(p.experience,100)
    }
    func testCivilianFailureNeverGrantsCurrencyOrStars() {
        var p = ProgressData()
        let r = MissionResult(mission:1,success:false,hits:1,shots:1,civilians:1,secondsLeft:50)
        XCTAssertEqual(r.stars,0); XCTAssertEqual(p.apply(r,reward:120,day:"today"),0)
        XCTAssertFalse(p.canPlay(2)); XCTAssertEqual(p.coins,0)
    }
    func testDailyChallengeCountsDistinctMissionsOnceAndResets() {
        var p = ProgressData()
        _ = p.apply(win(1),reward:120,day:"one"); _ = p.apply(win(1),reward:120,day:"one")
        XCTAssertEqual(p.completedToday,1)
        _ = p.apply(win(2),reward:150,day:"one")
        XCTAssertEqual(p.apply(win(3),reward:180,day:"one"),280)
        XCTAssertTrue(p.dailyClaimed)
        p.rollDay("two"); XCTAssertFalse(p.dailyClaimed); XCTAssertEqual(p.completedToday,0)
    }
    func testCosmeticsCannotSpendUnavailableMoneyAndSaveRoundTrips() throws {
        var p = ProgressData()
        XCTAssertFalse(p.buy("ice",price:150)); XCTAssertFalse(p.buy("invalid",price:0))
        p.coins = 150; XCTAssertTrue(p.buy("ice",price:150)); XCTAssertEqual(p.coins,0)
        XCTAssertFalse(p.buy("ice",price:150))
        let restored = try JSONDecoder().decode(ProgressData.self,from:JSONEncoder().encode(p))
        XCTAssertEqual(restored.selectedSkin,"ice"); XCTAssertEqual(restored.coins,0)
    }
}
